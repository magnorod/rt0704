#!/usr/bin/python3
import pika
connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
channel = connection.channel()
method_frame, header_frame, body = channel.basic_get('hello')
if method_frame:
    print("{} : {} : {}".format(method_frame, header_frame, body))
    channel.basic_ack(method_frame.delivery_tag)
else:
    print(" Rien à lire ")