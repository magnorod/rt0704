#!/usr/bin/python3

import pika

def creationFileNommee(connection, queue='hello'):
    channel = connection.channel()
    channel.queue_declare(queue)
    return channel

def ecritureSimpleFile(channel, nomFile, message):
    channel.basic_publish(exchange='', routing_key=nomFile, body=message)
    print("message envoyé : {}".format(message))

def lectureSimpleFile(channel, nomFile):
    method_frame, header_frame, body = channel.basic_get(nomFile)
    if method_frame:
        print(method_frame, header_frame, body)
        channel.basic_ack(method_frame.delivery_tag)


if __name__ == "__main__":
    nomFile = 'hello'
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = creationFileNommee(connection, nomFile)
    ecritureSimpleFile(channel, nomFile, "yolo")
    lectureSimpleFile(channel, nomFile)


