import docker

"""
@author: Aubriet Jonathan
"""

# permet de lancer un conteneur
def lancerConteneur(client, nomImage, nomConteneur, cmd):
    print(client.containers.run(image=nomImage, name=nomConteneur, command=cmd))

def buildConteneur(client, tag, path):
    print(client.images.build(tag=tag, path=path))

def listeConteneurUp(client):
    liste_id = client.containers.list(all=False)
    # boucle pour afficher les infos des machines
    for tmp in liste_id:
        print(tmp.id)

# main
if __name__ == '__main__':
    # lancement client
    client = docker.from_env()
    
    # build conteneur
    #buildConteneur(client, 'graphviz:1.02', '.')

    # lancement conteneur créé
    cmd = []
    #lancerConteneur(client, 'graphviz:1.02', 'grptest', cmd)

    # liste des conteneurs up
    listeConteneurUp(client)