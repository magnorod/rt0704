import docker

client = docker.from_env()
print(client.images.build(path='.',tag='graphviz:1.01'))
#help(client.images.build)